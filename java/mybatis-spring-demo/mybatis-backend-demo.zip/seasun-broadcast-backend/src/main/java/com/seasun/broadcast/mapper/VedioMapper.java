package com.seasun.broadcast.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.seasun.broadcast.model.Vedio;

public interface VedioMapper {
    
    @Select("select * from vedio")
    List<Vedio> findAll();
    
    @Select("select * from vedio where id=#{0}")
    Vedio findById(int id);
    
    @Update("update vedio set id=#{id},parent_id=#{parentId},user_id=#{userId},vedio_id#{vedioId},like_count=#{likeCount},content=#{content} where id=#{id}")
    void updateById(Vedio vedio);
    
    @Delete("delete from vedio where id=#{id}")
    void deleteById(int id);
}
