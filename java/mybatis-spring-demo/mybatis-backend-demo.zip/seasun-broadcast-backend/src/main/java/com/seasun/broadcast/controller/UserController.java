package com.seasun.broadcast.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    
}
