package com.seasun.broadcast.model;

public class CollectionListVedioRef {
    private int collectionListId;
    private int vedioId;

    public int getCollectionListId() {
        return collectionListId;
    }

    public void setCollectionListId(int collectionListId) {
        this.collectionListId = collectionListId;
    }

    public int getVedioId() {
        return vedioId;
    }

    public void setVedioId(int vedioId) {
        this.vedioId = vedioId;
    }

}
