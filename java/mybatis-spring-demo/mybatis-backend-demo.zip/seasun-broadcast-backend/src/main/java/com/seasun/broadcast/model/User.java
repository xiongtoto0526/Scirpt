package com.seasun.broadcast.model;

import java.util.Date;

public class User {
    private int id;
    private String userName;
    private String password;
    private int age;
    private int location;
    private String company;
    private float codingAge;
    private String favorateLanguage;
    private String skilledLanguage;
    private String interestedLanguage;
    private String favorateIDE;
    private String personalHomepage;
    private String email;
    private String avatarUrl;
    private String liveUrl;
    private String liveKey;
    private Date createTime;
    private Date updateTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public float getCodingAge() {
        return codingAge;
    }

    public void setCodingAge(float codingAge) {
        this.codingAge = codingAge;
    }

    public String getFavorateLanguage() {
        return favorateLanguage;
    }

    public void setFavorateLanguage(String favorateLanguage) {
        this.favorateLanguage = favorateLanguage;
    }

    public String getSkilledLanguage() {
        return skilledLanguage;
    }

    public void setSkilledLanguage(String skilledLanguage) {
        this.skilledLanguage = skilledLanguage;
    }

    public String getInterestedLanguage() {
        return interestedLanguage;
    }

    public void setInterestedLanguage(String interestedLanguage) {
        this.interestedLanguage = interestedLanguage;
    }

    public String getFavorateIDE() {
        return favorateIDE;
    }

    public void setFavorateIDE(String favorateIDE) {
        this.favorateIDE = favorateIDE;
    }

    public String getPersonalHomepage() {
        return personalHomepage;
    }

    public void setPersonalHomepage(String personalHomepage) {
        this.personalHomepage = personalHomepage;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getLiveUrl() {
        return liveUrl;
    }

    public void setLiveUrl(String liveUrl) {
        this.liveUrl = liveUrl;
    }

    public String getLiveKey() {
        return liveKey;
    }

    public void setLiveKey(String liveKey) {
        this.liveKey = liveKey;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
