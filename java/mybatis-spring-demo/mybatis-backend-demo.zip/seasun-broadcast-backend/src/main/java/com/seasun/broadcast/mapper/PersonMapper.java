package com.seasun.broadcast.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.seasun.broadcast.model.Person;

public interface PersonMapper {
    @Select("select * from person")
    List<Person> findAllPerson();
}
