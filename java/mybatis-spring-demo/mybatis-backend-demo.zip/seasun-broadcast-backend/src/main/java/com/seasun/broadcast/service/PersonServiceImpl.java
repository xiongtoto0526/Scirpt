package com.seasun.broadcast.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seasun.broadcast.mapper.PersonMapper;
import com.seasun.broadcast.model.Person;
@Service
public class PersonServiceImpl implements PersonService{
    @Autowired
    private PersonMapper personMapper;
    
    @Override
    public List<Person> queryAllPerson() {
        return personMapper.findAllPerson();
    }
}
