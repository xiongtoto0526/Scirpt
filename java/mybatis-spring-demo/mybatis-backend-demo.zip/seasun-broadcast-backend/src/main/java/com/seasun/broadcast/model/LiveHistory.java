package com.seasun.broadcast.model;

public class LiveHistory {
    private int id;
    private int userId;
    private String title;
    private String facePage;
    private int projectType;
    private int grade;
    private int codingLanguage;
    private String desc;
    private int livingTime;
    private int maxWatchingAudiences;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getFacePage() {
        return facePage;
    }
    public void setFacePage(String facePage) {
        this.facePage = facePage;
    }
    public int getProjectType() {
        return projectType;
    }
    public void setProjectType(int projectType) {
        this.projectType = projectType;
    }
    public int getGrade() {
        return grade;
    }
    public void setGrade(int grade) {
        this.grade = grade;
    }
    public int getCodingLanguage() {
        return codingLanguage;
    }
    public void setCodingLanguage(int codingLanguage) {
        this.codingLanguage = codingLanguage;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public int getLivingTime() {
        return livingTime;
    }
    public void setLivingTime(int livingTime) {
        this.livingTime = livingTime;
    }
    public int getMaxWatchingAudiences() {
        return maxWatchingAudiences;
    }
    public void setMaxWatchingAudiences(int maxWatchingAudiences) {
        this.maxWatchingAudiences = maxWatchingAudiences;
    }
    
    
}
