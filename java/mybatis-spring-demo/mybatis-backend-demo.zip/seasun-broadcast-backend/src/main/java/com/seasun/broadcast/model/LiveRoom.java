package com.seasun.broadcast.model;

import java.util.Date;

public class LiveRoom {
    private int id;
    private int userId;
    private String title;
    private String facePage;
    private int projectType;
    private int grade;
    private int codingLanguage;
    private String desc;
    private int watchingAudiences;
    private int experience;
    private int status;
    private int maxWatchingAudiences;
    private Date createTime;
    private Date updateTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFacePage() {
        return facePage;
    }

    public void setFacePage(String facePage) {
        this.facePage = facePage;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getProjectType() {
        return projectType;
    }

    public void setProjectType(int projectType) {
        this.projectType = projectType;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getCodingLanguage() {
        return codingLanguage;
    }

    public void setCodingLanguage(int codingLanguage) {
        this.codingLanguage = codingLanguage;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getWatchingAudiences() {
        return watchingAudiences;
    }

    public void setWatchingAudiences(int watchingAudiences) {
        this.watchingAudiences = watchingAudiences;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getMaxWatchingAudiences() {
        return maxWatchingAudiences;
    }

    public void setMaxWatchingAudiences(int maxWatchingAudiences) {
        this.maxWatchingAudiences = maxWatchingAudiences;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
