package com.seasun.broadcast.service;

import java.util.List;

import com.seasun.broadcast.model.Person;

public interface PersonService {
    public List<Person> queryAllPerson();
}
