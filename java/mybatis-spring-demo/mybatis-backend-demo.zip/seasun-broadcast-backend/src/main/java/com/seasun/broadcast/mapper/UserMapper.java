package com.seasun.broadcast.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.seasun.broadcast.model.User;

public interface UserMapper {
    
    @Select("select * from user")
    List<User> findAll();
    
    @Select("select * from user where id=#{0}")
    User findById(int id);
    
    @Update("update user set id=#{id},user_name=#{userName},password=#{password},age=#{age},location_id=#{locationId},company=#{company},"
            + "coding_age=#{codingAge},favorate_language=#{favorateLanguage},skilled_language=#{skilledLanguage},intersted_language=#{interstedLanguage},"
            + "favorate_IDE=#{favorateIDE},personal_homepage=#{personalHomepage},email=#{email},avatar_url=#{avatarUrl},live_url=#{liveUrl},"
            + "live_key=#{liveKey} where id=#{id}")
    void updateById(User user);
    
    @Select("delete from user where id=#{0}")
    void deleteById(int id);
}
