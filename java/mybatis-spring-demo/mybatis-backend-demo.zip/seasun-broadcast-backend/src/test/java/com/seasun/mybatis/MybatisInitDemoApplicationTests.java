package com.seasun.mybatis;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.seasun.broadcast.MybatisInitDemoApplication;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MybatisInitDemoApplication.class)
public class MybatisInitDemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
