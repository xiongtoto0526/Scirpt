'use strict'

import React,{Component} from 'react';
import {Provider} from 'react-redux';
import {StatusBar,View} from 'react-native';
import store from './Store/Store';
import App from './App';
import NavigationRouter from  './Navigation/NavigationRouter'

const storeInstance = store();

class Root extends Component {

    constructor(props){
    	super(props);
    	this.state = {
    	}
    }

	render() {
		return (
	          <Provider store = {storeInstance}>
		          <View style={{flex:1,backgroundColor:'black'}}>
		            <StatusBar barStyle='light-content' 
		             animated={true}/>
		            <NavigationRouter />
		          </View>
	          </Provider>
		)
	}
}

export default Root