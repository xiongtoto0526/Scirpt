'use strict'

import React,{Component} from 'react'
import {Text,Image,View,StyleSheet} from 'react-native'
// import TabNavigator from 'react-native-tab-navigator'; 
import Tabs from 'react-native-tabs';
import { Actions } from 'react-native-router-flux';

class App extends Component {
	constructor(props) {
		super(props);
		this.changePage = this.changePage.bind(this);
		this.state = {
			page : 'home'
		}
	}

	changePage(el) {
       this.setState({page:el.props.name});
       if(el.props.name === 'home'){
            Actions.home();
       }else if(el.props.name === 'live'){
            Actions.live();
       }
	}

	render() {
		return (
			<View>
			    <Tabs selected={this.state.page} style={{backgroundColor:'white'}}
		              selectedStyle={{color:'red'}} onSelect={this.changePage}>
		            <Text name="home" selectedIconStyle={styles.selectedIconStyle}>主页</Text>
		            <Text name="live" selectedIconStyle={styles.selectedIconStyle}>直播</Text>
		        </Tabs>
	        </View>
		)
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  selectedIconStyle: {
  	borderTopWidth : 2,
  	borderTopColor : 'red'
  }

})

export default App;