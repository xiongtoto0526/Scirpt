'use strict'

import React,{Component} from 'react';
import {Text,Image,View,TouchableOpacity} from 'react-native';
import { Scene, Router, TabBar, Modal, Schema, Actions, Reducer, ActionConst } from 'react-native-router-flux';

// all detail page define
import Splash from '../Containers/Splash';
import HomeScreen from '../Containers/Home/HomeScreen';
import LiveScreen from '../Containers/Live/LiveScreen';
import HomeDetailPageOne from '../Containers/Home/HomeDetailPageOne';
import HomeDetailPageTwo from '../Containers/Home/HomeDetailPageTwo';
import NestDetailOne from '../Containers/Home/NestDetailOne';
import NavigationDrawer from './NavigationDrawer'

class HomeTabIcon extends Component {
    render(){
        return (
        	<View>
              <Image style={{width:26,height:26}} source={this.props.selected ? require('../Images/ic_tab_home_active.png'):require('../Images/ic_tab_home.png')}></Image>
              <Text style={{fontSize:12,color: this.props.selected ? 'red' :'gray'}}>{this.props.title}</Text>
            </View>
        );
    }
}

class LiveTabIcon extends Component {
    render(){
        return (
        	<View>
              <Image style={{width:26,height:26}} source={this.props.selected ? require('../Images/ic_tab_live_active.png'):require('../Images/ic_tab_live.png')}></Image>
              <Text style={{fontSize:12,color: this.props.selected ? 'red' :'gray'}}>{this.props.title}</Text>
            </View>
        );
    }
}


class NavigationRouter extends Component {

  LeftDrawerIcon () {
    return (
      <TouchableOpacity onPress={()=> Actions.refresh({key: 'drawer',open: true})}>
          <Text style={{color: 'white'}}>setting</Text>
      </TouchableOpacity>
    )
  }

	render() {
		return (
			<Router>
        <Scene key="drawer" component={NavigationDrawer} open={false} >
            <Scene key='drawerChildrenWrapper'>
                <Scene key='splash' component={Splash} title='闪屏' hideNavBar={true} initial={true}/>
                <Scene key="tabbar" type={ActionConst.RESET} tabBarStyle={{backgroundColor:'white'}} tabs={true} >
                    <Scene key='home' title='主页' icon={HomeTabIcon} navigationBarStyle={{backgroundColor:'black'}} titleStyle={{color:'white'}}>
                       <Scene key='main' initial={true} component={HomeScreen}   hideTabBar={false} title='主页' drawerImage={require('../Images/ic_center_more.png')}/>
                       <Scene key='detail1' component={HomeDetailPageOne}   hideTabBar={true} title='主页详情1'/>
                       <Scene key='detail11' direction='vertical' duration={500}  hideTabBar={true} component={NestDetailOne} title='主页详情11'/>
                       <Scene key='detail2' component={HomeDetailPageTwo}  hideTabBar={true} hideNavBar={true} title='主页详情2'/>
                    </Scene>
                    <Scene key='live' component={LiveScreen} title='直播' navigationBarStyle={{backgroundColor:'black'}} titleStyle={{color:'white'}} icon={LiveTabIcon} drawerImage={require('../Images/ic_center_more.png')}/>
                </Scene>
            </Scene>    
        </Scene>
			</Router>
		)
	}
}

export default NavigationRouter;