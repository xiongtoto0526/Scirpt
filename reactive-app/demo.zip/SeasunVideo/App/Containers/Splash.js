'use strict';

import React from 'react';
import {
  Dimensions,
  Image,
  InteractionManager,
  View,
  Text,
} from 'react-native';
import { Actions } from 'react-native-router-flux';


var {height, width} = Dimensions.get('window');

class Splash extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
     this.timer=setTimeout(() => {
      Actions.tabbar();
    }, 2000);
  }


  componentWillUnmount() {
    this.timer && clearTimeout(this.timer);
  }
 
  render() {
    return (
      <View style={{flex:1}}>
      <Image
        style={{flex:1,width:width,height:height}}
        source={require('../Images/ic_welcome.jpg')}
        />
      </View>
    );
  }
}
export default Splash;