'use strict'

import React, {Component} from 'react';
import {View, Text} from 'react-native'
import CenterButton from '../../Components/CenterButton'

class LiveScreen extends Component {
	constructor(props){
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<View style={{flex:1,backgroundColor:'lightblue',justifyContent:'center'}}>
			  <CenterButton text=' This is live ' onPress={()=>console.log('hello')}></CenterButton>
			</View>
		)
	}
}

export default LiveScreen;