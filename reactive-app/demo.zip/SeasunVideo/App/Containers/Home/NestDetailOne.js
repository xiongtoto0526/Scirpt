'use strict'

import React, {Component} from 'react';
import {Platform, View, Text, StyleSheet} from 'react-native'
import { Actions } from 'react-native-router-flux';
import CenterButton from '../../Components/CenterButton'

class NestDetailOne extends Component {
	constructor(props){
		super(props);
		this.state = {

		}
	}

    static renderNavigationBar(props) {
    	debugger;
    	return(
             <View style={styles.header}>
             <Text style={styles.leftButton} onPress={()=>Actions.pop()}>返回</Text>
             <View style={styles.moreMenu}><Text style={{color:'white'}}>自定义菜单</Text></View>
             </View>
    	)
    }

	render() {
		return (
			<View style={{flex:1,backgroundColor:'#8DB6CD',justifyContent:'center'}}>
			  <CenterButton text='This is NestDetailOne' onPress={()=>console.log('hello')}></CenterButton>
			</View>
		)
	}
}


const styles = StyleSheet.create({
	header: {
    backgroundColor: 'black',
    paddingTop: 0,
    top: 0,
    ...Platform.select({
      ios: {
        height: 64,
      },
      android: {
        height: 54,
      },
    }),
    right: 0,
    left: 0,
    borderBottomWidth: 0.5,
    borderBottomColor: '#828287',
    position: 'absolute',
  },
  rightButton: {
  	color:'white',
    width: 100,
    height: 37,
    position: 'absolute',
    ...Platform.select({
      ios: {
        top: 25,
      },
      android: {
        top: 13,
      },
    }),
    right: 2,
    padding: 8,
  },
  leftButton: {
  	color:'white',
    width: 100,
    height: 37,
    position: 'absolute',
    ...Platform.select({
      ios: {
        top: 25,
      },
      android: {
        top: 13,
      },
    }),
    left: 2,
    padding: 8,
  },
  moreMenu: {
  	position: 'absolute',
  	...Platform.select({
      ios: {
        top: 64,
      },
      android: {
        top: 54,
      },
    }),
  	right: 0,
  	width: 150,
  	height: 200,
  	backgroundColor: 'gray',
  	padding: 10
  }
})

export default NestDetailOne;