'use strict'

import React, {Component} from 'react';
import {View, Text} from 'react-native'
import VideoPanel from '../../Components/VideoPanel'

class HomeDetailPageTwo extends Component {
	constructor(props){
		super(props);
		this.state = {

		}
	}

	render() {
		return (
		   <VideoPanel {...this.props} source={{uri: 'http://localhost:9082/video/background.mp4'}}/>
		)
	}
}

export default HomeDetailPageTwo;