'use strict'

import React, {Component} from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import { Actions } from 'react-native-router-flux';
import CenterButton from '../../Components/CenterButton'


class HomeScreen extends Component {
	constructor(props){
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<View style={{flex:1,backgroundColor:'gray',justifyContent:'center'}}>
			  <CenterButton style={{marginBottom:50}} onPress={Actions.detail1} text='go to home detail page one'></CenterButton>
			  <CenterButton onPress={Actions.detail2} text='go to home detail page two (video)'>  </CenterButton>
			</View>
		)
	}
}

const styles = StyleSheet.create({
	button: {
		color: 'white',
		backgroundColor: '#A2CD5A',
		paddingTop: 5,
		paddingBottom: 5,
		textAlign: 'center'
	}
})

export default HomeScreen;