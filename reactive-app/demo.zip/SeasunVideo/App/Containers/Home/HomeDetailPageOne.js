'use strict'

import React, {Component} from 'react';
import {View, Text} from 'react-native'
import { Actions } from 'react-native-router-flux';
import CenterButton from '../../Components/CenterButton'

class HomeDetailPageOne extends Component {
	constructor(props){
		super(props);
		this.state = {

		}
	}

	render() {
		return (
			<View style={{flex:1,backgroundColor:'#B4CDCD',justifyContent:'center'}}>
			  <CenterButton onPress={Actions.detail11} text='go to nest detail ...'></CenterButton>
			</View>
		)
	}
}

export default HomeDetailPageOne;