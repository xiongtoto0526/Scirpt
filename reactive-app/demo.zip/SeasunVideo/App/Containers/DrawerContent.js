import React, { Component } from 'react'
import { ScrollView, Image, StyleSheet } from 'react-native'
import CenterButton from '../Components/CenterButton'
import { Actions as NavigationActions } from 'react-native-router-flux'

class DrawerContent extends Component {

  toggleDrawer () {
    this.context.drawer.toggle()
  }

  handlePressComponents = () => {
    this.toggleDrawer()
    // NavigationActions.componentExamples()
  }

  handlePressUsage = () => {
    this.toggleDrawer()
  }

  handlePressAPI = () => {
    this.toggleDrawer()
  }

  handlePressTheme = () => {
    this.toggleDrawer()
  }

  handlePressDevice = () => {
    this.toggleDrawer()
  }

  render () {
    return (
      <ScrollView style={{flex: 1,backgroundColor: '#708090'}}>
        <Image style={{height:150,width:300,marginBottom:20}}source={require('../Images/ic_top.png')}/>
        <CenterButton style={styles.button} text='first menu item' onPress={this.handlePressComponents} />
        <CenterButton style={styles.button} text='second menu item' onPress={this.handlePressUsage} />
        <CenterButton style={styles.button} text='third menu item' onPress={this.handlePressAPI} />
        <CenterButton style={styles.button} text='fourth menu item' onPress={this.handlePressTheme} />
        <CenterButton style={styles.button} text='fifth menu item' onPress={this.handlePressDevice} />
      </ScrollView>
    )
  }

}

DrawerContent.contextTypes = {
  drawer: React.PropTypes.object
}

const styles = StyleSheet.create({
	button: {
	    marginBottom:10
	}
})

export default DrawerContent
