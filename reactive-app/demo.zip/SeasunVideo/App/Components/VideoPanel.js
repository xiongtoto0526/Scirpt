'use strict'
import React,{PropTypes,Component} from 'react'
import {View,Text,Image,TouchableOpacity,Animated,Easing,Dimensions,StyleSheet} from 'react-native'
import {Actions} from 'react-native-router-flux';
import {RenderIf} from '../Utils/CommonUtils';
import Video from 'react-native-video';
import Slider from 'react-native-slider';
import Orientation from 'react-native-orientation';

const statusBarHeight = 20;
const videoPanelHeight = 240;
const controlsHeight = 30;

class VideoPanel extends Component {
	constructor(props){
		super(props);
        this.onLoad = this.onLoad.bind(this);
        this.onProgress = this.onProgress.bind(this);
        this.onToggleControlView = this.onToggleControlView.bind(this);
        this.onChangeOrient = this.onChangeOrient.bind(this);
        this.onSeed = this.onSeed.bind(this);
        this.onSlideProgress = this.onSlideProgress.bind(this);
        this.formatDuration = this.formatDuration.bind(this);
        Orientation.addOrientationListener(this.onChangeOrient);

		this.state = {
			value:0,
		    duration: 0.0,
		    currentTime: 0.0,
		    controls: false,
		    paused: true,
		    isOrientH : false,
		    controlMarginTop: new Animated.Value(0),
        navBarMarginTop: new Animated.Value(0)
		}
	}

    onLoad(data) {
        this.setState({duration: data.duration});
    }

    onProgress(data) {
    	let completedLength = 0;
    	if (this.state.currentTime > 0) {
            completedLength =  parseFloat(this.state.currentTime) / parseFloat(this.state.duration);
        } 
        this.setState({currentTime: data.currentTime});
        this.setState({
        	value: completedLength
        })
    }

    onToggleControlView(){
	    let toValue = this.state.controlMarginTop._value!=0 ? 0 : 30;
	    Animated.timing(this.state.controlMarginTop,{
	      toValue:toValue,duration:200,easing:Easing.linear
	    }).start();

      let navtoValue = this.state.navBarMarginTop._value!=0 ? 0 : -100;
      Animated.timing(this.state.navBarMarginTop,{
        toValue:navtoValue,duration:200,easing:Easing.linear
      }).start();
    }

    onChangeOrient(or) {
	    if(or == 'LANDSCAPE'){
	      this.setState({isOrientH:true})
	    }else{
	      this.setState({isOrientH:false})
	    }
	}

	onSlideProgress(value){
        this.setState({value:value,currentTime:value*this.state.duration});
	}

	onSeed(value){
        this.refs.myVideo.seek(value*this.state.duration);
        this.setState({value:value,currentTime:value*this.state.duration,paused: false});
	}

    formatDuration(seconds){
	  var hour,min,second;
	  hour = parseInt(seconds/3600);
	  hour = hour<10 ? '0' + hour : hour;
	  min = parseInt((seconds%3600)/60);
	  min = min<10 ? '0' + min : min;
	  second = parseInt((seconds%3600)%60);
	  second = second<10 ? '0' + second : second;
	  return this.state.duration>=3600 ? '' + hour +':'+ min +':'+ second : min +':'+ second;
	}

    componentWillUnmount(){
      Orientation.removeOrientationListener(this.onChangeOrient);
    }

	render(){

		return(
          <View style={[styles.container,{height:this.state.isOrientH ? Dimensions.get('window').height:videoPanelHeight}]}>
             <TouchableOpacity activeOpacity={1} style={this.state.isOrientH ? styles.fullScreen : styles.portaitScreen} onPress={this.onToggleControlView}>
	            <Video
	            ref="myVideo"
	            style={this.state.isOrientH ? styles.fullScreen : styles.portaitScreen}
	            rate={1}
	            paused={this.state.paused}
	            volume={1}
	            muted={false}
	            resizeMode='cover'
	            onLoad={this.onLoad}
	            onProgress={this.onProgress}
	            onEnd={() => { console.log('done...'); }}
	            repeat={true}
                {...this.props}
	             />
             </TouchableOpacity>
             <Animated.View style={[styles.controls,{top:this.state.isOrientH ? Dimensions.get('window').height-controlsHeight:videoPanelHeight-controlsHeight},{
              marginTop:this.state.controlMarginTop}]}>
	            <View style={styles.progress}>
	              <TouchableOpacity style={{width:controlsHeight}} onPress={() => {this.setState({paused: !this.state.paused})}}>
	              <Image style={{width:20,height:20,marginLeft:10}} source={this.state.paused? require('../Images/play.png'):require('../Images/pause.png')}></Image>
	              </TouchableOpacity>
	              
	              <Slider minimumTrackTintColor='#1fb28a' style={{marginLeft:10,width:Dimensions.get('window').width-140}}
	              maximumTrackTintColor='black'
	              thumbTintColor='#1a9274'
	              value={this.state.value}
	              thumbStyle={{height:12,width:12}}
	              onValueChange={this.onSlideProgress}
	              onSlidingStart={() => {this.setState({paused: true})}}
	              onSlidingComplete={this.onSeed} 
	              />
	              
	              <Text style={styles.text}>{this.formatDuration(this.state.currentTime)}/{this.formatDuration(this.state.duration)}</Text>

	              <TouchableOpacity style={styles.screenBtn}  onPress={this.state.isOrientH ? Orientation.lockToPortrait:Orientation.lockToLandscapeLeft} >
	               <Image style={{width:15,height:15}} source={this.state.isOrientH? require('../Images/fullscreen_exit.png'):require('../Images/fullscreen_enter.png')}></Image>
	              </TouchableOpacity>
	            </View>
             </Animated.View>
             
             {RenderIf(!this.state.isOrientH)(
             <Animated.View style={[{top:-statusBarHeight+10,height:30},{marginTop:this.state.navBarMarginTop}]}>
                <TouchableOpacity onPress={this.state.isOrientH ? Orientation.lockToPortrait:()=>Actions.pop()} style={{flex:1, backgroundColor: 'rgba(51,51,51,0.5)'}}><
                  Text style={{color:'white',paddingTop:7,paddingLeft:5}}>返回</Text>
                </TouchableOpacity>
             </Animated.View>)}
          </View>
		);
	}


}
const styles = StyleSheet.create({
	container: {
	  backgroundColor: 'black',
      height: videoPanelHeight,
      overflow: 'hidden'
	},
	controls: {
      height: 30
	},
	fullScreen: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0
    },
    portaitScreen: {
      position: 'absolute',
      top: 10,
      left: 0,
      height:videoPanelHeight,
      right: 0,
    },
    progress: {
    flex: 1,
    flexDirection: 'row',
    overflow: 'hidden',
    height:controlsHeight,
    alignItems: 'center',
    backgroundColor: 'rgba(51,51,51,0.5)'
  },
    text: { 
     position:'absolute',
     right:30,
     top:9,
     marginLeft:12,
     color:'white',
     fontSize:10,
  },
    screenBtn: {
    position:'absolute',
    right:0,
    top:7,
    width:25,}
})

export default VideoPanel;