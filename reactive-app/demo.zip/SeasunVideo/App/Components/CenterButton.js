import React, { Component, PropTypes } from 'react'
import { Text, TouchableOpacity, StyleSheet } from 'react-native'

class CenterButton extends Component {
  render () {
    return (
      <TouchableOpacity style={this.props.style} onPress={this.props.onPress}>
        <Text style={styles.button}>{this.props.text}</Text>
      </TouchableOpacity>
    )
  }
}

CenterButton.propTypes = {
  text: PropTypes.string.isRequired,
  onPress: PropTypes.func.isRequired
}


const styles = StyleSheet.create({
	button: {
		color: 'white',
		backgroundColor: '#A2CD5A',
		paddingTop: 5,
		paddingBottom: 5,
		textAlign: 'center'
	}
})

export default CenterButton
