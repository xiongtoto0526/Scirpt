'use strict'

import * as types from '../Constants/ActionTypes';

const initialState = {
	loading : false,
	isLogined : false,
	data : ''
}

export default function login(state = initialState, action) {
	switch(action.type) {
        case types.perform_login_action :
            return Object.assign({}, state, {
            	loading : true,
            	isLogined : false
            });
        case types.receive_login_action :
            return Object.assign({}, state, {
            	loading : false,
            	isLogined : true,
            	data : action.result
            });
        default :
            return state;
	}
}