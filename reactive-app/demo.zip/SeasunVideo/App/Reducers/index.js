'use strict'

import {combineReducers} from 'redux';
import login from './LoginReducers';

const rootReducer = combineReducers({
	login
})

export default rootReducer;