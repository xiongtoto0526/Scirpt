import store from 'react-native-simple-store';


/*
添加用户到本地
*/
export function addUser(id, name, token) {
  store.save('user', {
    id: id,
    name: name,
    token: token
  }).then(()=>store.get('userNames').then(result=>{
    console.log(result);
    var userNameList = [];
  	if(!result){
  		userNameList.push(name);
  	}else{
  	   userNameList = result;
  	   if(userNameList.indexOf(name)==-1){
          userNameList.push(name);
  		}
  	}
  	store.save('userNames',userNameList)
  	.then(()=>store.get('userNames')).then(newUsers=>console.log(newUsers))
  }));
}

/*
返回所有此设备登陆过的用户
*/
export function findLocalUsers() {
  return store.get('userNames');
}

/*
返回最后登陆的用户
*/
export function findLatestUser() {
  return store.get('user');
}

/*
清空所有用户记录
*/
export function removeAllUsers() {
  store.delete('user');
  store.delete('userNames')
}


