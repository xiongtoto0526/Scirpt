'use strict';

import {HOST,LOGIN_ACTION,VERIFY_ACTION} from '../constants/Request';
import {IsDev} from './CommonUtils';

// ---- business request -----
export function isUserValid(token){

  if(IsDev()){
    return new Promise((resolve,reject)=>{
        resolve({code:0});
      })
  }


  if(!token){
    return new Promise((resolve,reject)=>{
      resolve({code:-1});
    })
  }

   return getRequest(VERIFY_ACTION,token);
}

export function login(body){
   if(IsDev()){
      return new Promise((resolve,reject)=>{
      resolve({code:0,data:{id:123,token:'448yyii9'}});
    })
   }

  return postRequest(LOGIN_ACTION,body,'-1');
}


// ---- basic request -----
export function getRequest(url,token){

  if(!token){
   token = window.token;
  }
  return new Promise((resolve, reject) => {
    fetch(HOST + url, {
        headers: {
             'token': token,
          },
        method: 'GET',
      })
      .then((response) => {
        return response.json();
      })
      .then((responseData) => {
          resolve(responseData);
      })
      .catch((error) => {
          reject(error);
      });
  })
}


export function postRequest(url,body,token) {
  var isOk = false;

  if(!token){
   token = window.token;
  }
  return new Promise((resolve, reject) => {
    fetch(HOST + url, {
        method: 'POST',
         headers: {
        'token': token,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      })
      .then((response) => {
        if (!response.error) {
          isOk = true;
        } else {
          isOk = false;
        }
        return response.json();
      })
      .then((responseData) => {
        if (isOk) {
          resolve(responseData);
        } else {
          reject(responseData);
        }
      })
      .catch((error) => {
        reject(error);
      });
  })
}
