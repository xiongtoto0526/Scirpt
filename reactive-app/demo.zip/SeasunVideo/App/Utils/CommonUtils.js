'use strict';

export function NaviGoBack(navigator) {
	if (navigator && navigator.getCurrentRoutes().length > 1) {
		navigator.pop();
		return true;
  }
  return false;
}

export function NaviGoNew(navigator,name,component) {
	if (navigator) {
        navigator.push({
          component: component,
          name: name
           });
  }
}

export function isEmptyObject(obj) {
	for (var name in obj) {
		return false;
	}
	return true;
}

export function RenderIf(flag){
     return function (viewContent){
        return flag? viewContent : null;
     };
}

export function IsDev(){
     return process.env.NODE_ENV === 'development'
}