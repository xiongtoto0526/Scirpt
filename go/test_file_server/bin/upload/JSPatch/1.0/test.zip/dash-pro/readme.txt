1.双击dmg
2.zip为安装包，sp为补丁包
3.先安装，再补丁（双击，选择dash即可）
4.done