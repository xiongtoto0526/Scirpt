//
//  main.m
//  DEMO
//
//  Created by clq on 13-8-12.
//  Copyright (c) 2013年 hexc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PCAppDelegate class]));
    }
}
