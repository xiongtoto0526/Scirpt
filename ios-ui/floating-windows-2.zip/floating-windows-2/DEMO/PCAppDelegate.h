//
//  PCAppDelegate.h
//  DEMO
//
//  Created by clq on 13-8-12.
//  Copyright (c) 2013年 hexc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HEXCMyCustomTabBarControllerViewController;

@interface PCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) HEXCMyCustomTabBarControllerViewController *tabBarViewController;

@end
