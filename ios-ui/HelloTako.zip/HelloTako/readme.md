### 注意事项：

- 1. 需要添加 httpEnable 选项
- 2. 支持ios系统7.0

### todo:
- 1. 特殊logo无法显示。http://tako.kssws.ks-cdn.com/test/logo/99f4a84b-9049-4af7-4da0-ed504e9ece74.png
- 2. bar中的图片分辨率



### 测试场景
- 1 带密码，不带密码
- 2 暂停，恢复，反复测试
- 3 6.0的icon

### 标签说明
- todo
- refactor
- t







 
