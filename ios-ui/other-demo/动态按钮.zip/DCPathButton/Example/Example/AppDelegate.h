//
//  AppDelegate.h
//  Example
//
//  Created by tang dixi on 12/8/14.
//  Copyright (c) 2014 Tangdxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
