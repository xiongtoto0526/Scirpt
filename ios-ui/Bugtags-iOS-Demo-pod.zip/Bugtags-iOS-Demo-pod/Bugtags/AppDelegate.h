//
//  AppDelegate.h
//  Bugtags
//
//  Created by Bugtags on 15/7/28.
//  Copyright (c) 2015年 bugtags.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

