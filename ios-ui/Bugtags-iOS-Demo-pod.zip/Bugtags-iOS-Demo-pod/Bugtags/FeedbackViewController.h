//
//  FeedbackViewController.h
//  Bugtags
//
//  Created by Stephen Zhang on 7/29/15.
//  Copyright (c) 2015 bugtags.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedbackViewController : UIViewController

@end
