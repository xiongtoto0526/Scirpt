#!/bin/bash
#set -x
################################################################
#  put this script in the same path of portal|server|tasks dir #  
#                                                              #
################################################################

now=`date +%Y%m%d`
#-Xss thread memory default 1m
#-Xms 1024m jvm min memory
#-Xmx 2048m jvm max memory default is systerm memory 1/4
#-XX:MaxPermSize=256m 
command='java -Xms1024m -Xmx2048m -jar '

localPath=$(pwd)

portalPath=${localPath}'/portal/'
serverPath=${localPath}'/server/'
tasksPath=${localPath}'/tasks/'

Portal='com.xgsdk.message.portal-0.0.1-SNAPSHOT.war'
Server='com.xgsdk.message.server-0.0.1-SNAPSHOT.war'
Tasks='com.xgsdk.message.tasks-0.0.1-SNAPSHOT.war'

log_file_url=${now}_stdout.log
echo $log_file_url
# start stop restart all,portal,server,tasks 

function startPortal
{
	echo "startPortal enter"
	cd ${portalPath} && exec ${command}${Portal} &
}

function startServer
{
	echo "startServer enter"
	cd ${serverPath} && exec ${command}${serverPath}${Server} &
}

function startTasks
{
	echo "startTasks enter"
	cd ${tasksPath} && exec ${command}${tasksPath}${Tasks} &
}

function KILL_FUWU {
    if [[ $PID != "" ]];then
        for i in $PID;do
            kill $PID >/dev/null 2>&1
            sleep 3
            kill -9 $PID >/dev/null 2>&1
        done
    fi
}


function CAT_FUWU {
       if [ -z $PID ];then
           case $SIGNAL in
           start|restart)
               echo "正在启动 $FUWU 服务"
           ;;
           stop)
               echo "$FUWU 服务已经关闭"
               exit
           ;;
           status)
               echo "$FUWU 服务处于关闭"
           ;;
           esac
       else
           case $SIGNAL in
           start)
               echo "$FUWU 服务已经开启"
               exit 0
           ;;
           stop|restart)
               echo "你所要杀掉的 $FUWU 服务对应的进程号为 $PID"
           ;;
           status)
               echo "$FUWU 服务目前正在运行，对应的进程号为 $PID"
           ;;
           esac
       fi
}


function FUWU_LIST {
    case $SIGNAL in
    start)
        CAT_FUWU
        $1
    ;;
    stop)
        CAT_FUWU
        KILL_FUWU
    ;;
    restart)
        CAT_FUWU
        KILL_FUWU
        $1
    ;;
    status)
        CAT_FUWU
    ;;
    *)
        USAGE
    ;;
    esac
}

function PORTAL 
{ 
    PID=`ps -ef|awk  '$0~"com.xgsdk.message.portal"&&$0!~"awk"{print $2}'`
    FUWU_LIST startPortal
}

function SERVER
{ 
    PID=`ps -ef|awk  '$0~"com.xgsdk.message.server"&&$0!~"awk"{print $2}'`
    FUWU_LIST startServer
}

function TASKS 
{ 
    PID=`ps -ef|awk  '$0~"com.xgsdk.message.tasks"&&$0!~"awk"{print $2}'`
    FUWU_LIST startTasks
}

FUWU=$1
SIGNAL=$2

case $1 in
portal)
    PORTAL
;;
server)
    SERVER
;;
tasks)
    TASKS
;;
*)
    echo "###############################################################"
    echo "    $0 {Portal|Server|Tasks} {start|stop|restart|status}"
    echo "###############################################################"
;;
esac
exit 0
